<html>
    <head>
        <title>
            Log in
        </title>
    </head>
 <body>
 	<div class="container">
 		<div class="col-sm-6">
 			<div class="panel panel-default">
 				<div class="panel-heading">
					
					<b>Iniciar Sesión</b>
 				</div>
 					<div class="panel-body">
 						
 						<form action="login.php" method="POST">
 							<div class:"form-group">
								<input type="text" name="username" id="" class="form-control" placeholder="Username">
							</div>
							<div class:"form-group">
								<input type="password" name="Password" id="" class="Password" placeholder="Password">
							</div>
							<div class:"form-group">
								<input type="submit" value="Log in" class="btn btn-danger">
							</div>
						</form>
					</div>
			</div>
		</div>
	</div>
  </body>
</html>