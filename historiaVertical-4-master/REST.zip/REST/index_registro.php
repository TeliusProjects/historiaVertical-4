<html>
    <head>
        <title>
            Registration
        </title>
    </head>
 <body>
 	<div class="container">
 		<div class="col-sm-6">
 			<div class="panel panel-default">
 				<div class="panel-heading">
					<b>Add user </b>
 				</div>
 					<div class="panel-body">
 						<form action="register.php" method="POST">
							<div class:"form-group">
								<input type="text" name="username" id="" class="form-control" placeholder="Username">
							</div>
							<div class:"form-group">
								<input type="password" name="password" id="" class="form-control" placeholder="Password">
							</div>
							<div class:"form-group">
								<input type="password" name="password2" id="" class="form-control" placeholder="Confirm password">
							</div>
							<div class:"form-group">
								<input type="text" name="Email" id="" class="Password" placeholder="Email">
							</div>
							<div class:"form-group">
								<input type="text" name="Email2" id="" class="Password" placeholder="Email2">
							</div>
							<div class:"form-group">
								<input type="submit" name="bttn_register"value="Register" class="btn btn-danger">
							</div>
						</form>
					</div>
			</div>
		</div>
	</div>
  </body>
</html>